<?php
    \WPML\Setup\Initializer::loadJS();
?>


<div class="wrap wpml-settings-container wpml-wizard">
    <h2><?php _e( 'WPML Setup', 'sitepress' ) ?></h2>

    <div id="wpml-wizard__content"></div>
</div>