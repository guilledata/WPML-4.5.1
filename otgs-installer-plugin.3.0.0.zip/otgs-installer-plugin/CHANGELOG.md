# Changelog
## 3.0.0
- Updating installer library and adjusting plugin version.

## 1.0.0

- Lightweight Installer plugin that allows to install OTGS plugins.
