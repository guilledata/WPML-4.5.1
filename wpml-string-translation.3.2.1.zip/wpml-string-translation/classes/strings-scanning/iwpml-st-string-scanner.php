<?php

interface IWPML_ST_String_Scanner {

	public function scan();
}
